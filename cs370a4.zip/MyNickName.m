%initial array
segx = zeros(2,5);
segy = zeros(2,5);
segx(1,:) = [100 90 80 180 250];
segy (1,:) = [0 -150 -300 -290 -300];
segx(2,:) = [350 300 400 500 600 ];
segy(2,:) = [-150 -300 -200 -150 -200 ];
segx(3,:) = [600 500 400 450 500 ];
segy(3,:) = [-200 -300 -200 -160 -150];
segx(4,:) = [500 600 650 700 650];
segy(4,:) = [-150 -170 -160 -150 -300];
segx(5,:) = [650 800 790 800 850];
segy(5,:) = [-300 -150 -200 -300 -225];
for i = 1:5
[x_sc,y_sc,t]=ParametricSpline(segx(i,:),segy(i,:));

% Create a finer sampling of the parameter.
tt = linspace(t(1),t(end),100);

% Evaluate the spline at that finer resolution.
Sx = EvaluateMySpline(t,x_sc,tt);
Sy = EvaluateMySpline(t,y_sc,tt);

% And plot the points and the spline.
hold on;
plot(Sx,Sy,'bd',segx(i,:),segy(i,:),'ro');
end
xlim([0,900])
axis equal