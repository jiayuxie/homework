% unlock.m script

% Display grid of 16 circles
[gx, gy] = meshgrid([0 20 40 60], [0 20 40 60]);
plot(gx(:), gy(:),'ko', 'MarkerSize',10);
hold on; % don't erase plot on next plot command


% --- YOUR CODE HERE ---
x = [0 27 50 -4 22];
y = [-1 37 27 11 42];
tt =linspace(0,2897,2897);
t = [0 795 1447 2172 2897];
x_cs = MySpline(t,x);
y_cs = MySpline(t,y);
Sx = EvaluateMySpline(t,x_cs,tt);
Sy = EvaluateMySpline(t,y_cs,tt);
plot(Sx,Sy);
