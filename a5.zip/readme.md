I merge the training and test data to 1 file ,and add a -1 between them.
When the program read the -1,it will automictly switch to testing mode,and display the tree(attribute index,threshold),(from top to botton,from left to right),and the testing data.
simple run g++14 -o a5 a5.cc
	   ./a5<TrainAndTest.txt
