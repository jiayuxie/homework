#include<vector>
#include<iostream>
#include<utility>
#include<cmath>
#include<sstream>
#include<queue>
using namespace std;

class node {
	public:
	string Name;//for debug
	double threshold=0;//only for nonleaf node
	int nodeAtr;
	bool isleaf;
	bool result;//only for leaf node,false for healthy,true otherwise
	node* lower=NULL;
	node* upper=NULL;
	node(){}
	node(bool b){
		isleaf = true;
		result = b;
		if(b==true) Name = "colic";
		else{
			Name="healthy";
		}
	}
	node(string n,double t,int atr){
		isleaf = false;
		Name =n;
		threshold = t;
		nodeAtr = atr;
	}
};


class DTree{
	public:
	vector<vector<double>> data;
	vector<vector<double>> test;
	//input data (N*17)matrix include 16 attributes including result
	node* root=NULL;//the tree
	DTree(){
		data.resize(17);	
		test.resize(17);
	}
	vector<vector<double>> createExample(int mode){
		vector<vector<double>> mdata;
		if(mode==0){
			mdata = data;
		}
		if(mode==1){
			mdata = test;
		}			
		int h = mdata[0].size();
		int l = mdata.size();
		vector<vector<double>> example;
		example.resize(h);
		for(int i=0;i<h;i++){
			example[i].resize(l);
		}
		for(int i=0;i<mdata.size();i++){
			for(int j=0;j<mdata[i].size();j++){
				example[j][i] = mdata[i][j];
			}
		}
		return example;
	}

	void RunTraining(){
		vector<int> attributes;
		for(int i =0;i<16;i++){
			attributes.push_back(i);
		}
		vector<vector<double>> example = createExample(0);
		root = ID3(example,attributes);
	}

	vector<double> uniqueSort(vector<vector<double>> example,int att){
			vector<double> sorted;
			for(int i=0;i<example.size();i++){
				int found = -1;
				for(int j=0;j<sorted.size();j++){
					if(example[i][att]==sorted[j]){
						found = j;
						break;
					}
				}
				if(found==-1){	
					sorted.push_back(example[i][att]);
				}
			}
			//sort the unique vector
			for(int a =1;a<sorted.size();++a){
				for(int b=a;b>0;--b){
					if(sorted[b]<sorted[b-1]){
						swap(sorted[b],sorted[b-1]);
					}
				}
			}
		return sorted;
				
	}
	double Calinfo(vector<vector<double>> example){
		double pos=0;
		double neg=0;
		for(int i=0;i<example.size();i++){
			if(example[i][16]==1){
				pos++;
			}
			if(example[i][16]==0){
				neg++;
			}
		}
		double info1 = -(pos/(pos+neg))*log2(pos/(pos+neg));
		double info2 = -(neg/(pos+neg))*log2(neg/(neg+pos));
		if(pos==0) info1=0;
		if(neg==0) info2=0;
		double info = info1+info2;
		return info;
	}
	void ChooseAttribute(vector<int> Attributes,vector<vector<double>> example,int& best,double& t){
		double info = Calinfo(example);
		double maxIG=-10000;
		best=-1;
		for(int m=0;m<Attributes.size();m++){//for every attributes
			int i = Attributes[m];
			vector<double> allthreshold;
			vector<double> sorted  = uniqueSort(example,i);
			for(int k=0;k<sorted.size()-1;k++){
				allthreshold.push_back((sorted[k]+sorted[k+1])/2);
			}
			for(int j=0;j<allthreshold.size();j++){//try all possible threshold
				double cur = allthreshold[j];
				vector<vector<double>> lpart;
				vector<vector<double>> upart;
				int pl=0;
				int nl=0;
				int pu=0;
				int nu=0;
				for(int k=0;k<example.size();k++){
					if(example[k][i]<cur){
						if(example[k][16]==1){
							pl++;
						}
						else{
							nl++;
						}
						lpart.push_back(example[k]);
					}
					else{
						upart.push_back(example[k]);
						if(example[k][16]==1){
							pu++;
						}
						else{
							nu++;
						}
					}
				}
				double remainder = ((pl+nl)/(double)example.size())*Calinfo(lpart)+((pu+nu)/(double)example.size())*Calinfo(upart);
				double curIG = info - remainder;
				if(curIG>maxIG){
					maxIG = curIG;
					best = i;
					t = cur;
				}
			}
		}
	}
				
			

	node* ID3(vector<vector<double>> Examples,vector<int> Attributes){
		if(Examples.size()==0){
			return NULL;
		}
		int sum=0;
		for(int i=0;i<Examples.size();i++){
			sum+=(int)Examples[i][16];
		}
		if(sum==0){
			node* leaf =new node(false);
			return leaf;
		}
		if(sum==Examples.size()){
			node* leaf = new node(true);
			return leaf;
		}
		if(Attributes.size()==0){
			if(sum>=Examples.size()/2){
				node* leaf = new node(true);
				return leaf;
			}
			else{
				node* leaf = new node(false);
				return leaf;
			}
		}
		else{
			int best;
			double t;
			ChooseAttribute(Attributes,Examples,best,t);
			for(int i=0;i<Attributes.size();i++){
				if(Attributes[i]==best){
					Attributes.erase(Attributes.begin()+i);
					break;
				}
			}
			stringstream ss;
			ss<<best;
			string s;
			ss>>s;	
			node* mytree = new node(s,t,best);
			//lower part========================
			vector<vector<double>> lexamples;
			for(int i =0;i<Examples.size();i++){
				if(Examples[i][best]<t){
					lexamples.push_back(Examples[i]);
				}
			}
			node* lchild = ID3(lexamples,Attributes);
			if(lchild) mytree->lower = lchild;
			vector<vector<double>> uexamples;
			for(int i=0;i<Examples.size();i++){
				if(Examples[i][best]>=t){
					uexamples.push_back(Examples[i]);
				}
			}
			node* uchild = ID3(uexamples,Attributes);
			if(uchild) mytree->upper = uchild;
			return mytree;
		}
	} 
			
	void displayTree(){
		queue<node*> treequeue;
		treequeue.push(root);
		while(treequeue.size()){
			node* p = treequeue.front();
			treequeue.pop();
			cout<<p->Name<<" "<<p->threshold<<" ";
			if(p->lower) treequeue.push(p->lower);
			if(p->upper) treequeue.push(p->upper);
		}
	}
	void runTest(int mode){//train mode:0,test mode:1
		vector<vector<double>> example = createExample(mode);
		node* curp=root;
		int correct=0;
		int wrong=0;
		for(int i=0;i<example.size();i++){
			while(curp->isleaf!=true){
				if(example[i][curp->nodeAtr]<curp->threshold){
					curp=curp->lower;
				}
				else{
					curp=curp->upper;
				}
			}
			if(curp->result == (bool)example[i][16]){
				correct++;
			}
			else{
				wrong++;
			}
			curp=root;
		}
		if(mode==0){
			cout<<"\ntraining data :\n";
		}
		else{
			cout<<"test data:\n";
		}
		cout<<"correct= "<<correct<<" wrong= "<<wrong<<endl;
		
	}
					 
};

int main(){
	DTree tree;
	while(1){
		double curdata;
        	string s;
		cin>>curdata;
		if(curdata==-1) break;
		tree.data[0].push_back(curdata);
		for(int i=1;i<16;i++){
			cin>>curdata;
			tree.data[i].push_back(curdata);
		}
		cin>>s;
		double result=0;
		if(s=="colic.") result =1;
		tree.data[16].push_back(result);
	}
	while(1){
		double testdata;
		string s;
		cin>>testdata;
		if(cin.eof()) break;
		tree.test[0].push_back(testdata);
		for(int i=1;i<16;i++){
			cin>>testdata;
			tree.test[i].push_back(testdata);
		}
		cin>>s;
		double result=0;
		if(s=="colic.") result=1;
		tree.test[16].push_back(result);
	}
	tree.RunTraining();
	tree.displayTree();
	tree.runTest(0);
	tree.runTest(1);
}
		
