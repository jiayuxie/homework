from prison import Player

class Repeater(Player):
    """
    repeater conquer the world
    """
    #def __init__(self): # default constructor
        
    def studentID(self):
        return "20543555"
    def agentName(self):
        return "Repeater"
    def play(self, myHistory, oppHistory1, oppHistory2):
        matchnum =len(myHistory);
	if matchnum<2:
		 return 1 
	lastopp1 = oppHistory1[matchnum-1];
	last2opp1 = oppHistory1[matchnum-2];
	lastopp2 = oppHistory2[matchnum-1];
	last2opp2 = oppHistory2[matchnum-2];#get the choices of two last round
	opp1 = 0;
	opp2 =0;
	if lastopp1 and last2opp1:
		opp1 = 1;
	if lastopp2 and last2opp2:
		opp2 = 1; 
	if opp1 and opp2:
		return 1;
	if not opp1 and not opp2:
		return 0;
	else:
		return 1;
		
	
		
