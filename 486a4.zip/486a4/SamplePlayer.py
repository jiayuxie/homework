from prison import Player

class SamplePlayer(Player):
    """
    This is an example player
    """
    #def __init__(self): # default constructor
        
    def studentID(self):
        return "42"
    def agentName(self):
        return "Nice Player"
    def play(self, myHistory, oppHistory1, oppHistory2):
        return 0;
		
