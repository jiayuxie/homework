tspan=[11.5,22.43]
y0=[37.5;1;1]
[t,y]=ode45(@dying,tspan,y0)
plot(t,y(:,1))
axis([11 23 20 40])
xlabel('time (h)');
ylabel('core temperature (c)');
title(['dead at 11:30 am'], 'FontSize', 14);