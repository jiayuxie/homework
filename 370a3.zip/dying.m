function dzdt = dying(t,z)
    dzdt = zeros(3,1);
    dzdt(1)=-0.2*(z(1)-airtemp(t))+(z(2)+z(3))/100;
    T=z(1);
    if(T>=29 & T<=45)
        dzdt(2)=0.0008*((T-29)^2)*(1-exp(0.08*(T-45)))*z(2)*(50-z(2));
    else
        dzdt(2)=0;
    end
    if(T>=17 & T<=27)
        dzdt(3)=0.001*((T-17)^2)*(1-exp(0.05*(T-27)))*z(3)*(50-z(3));
    else
        dzdt(3)=0;
    end
    