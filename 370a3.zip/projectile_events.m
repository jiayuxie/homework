%function value = projectile_events(t,z)
%
function value = projectile_events(t,z)
    d = z(1);
	value = z(2)-Ground(d);
    