% function G = myJPEGCompress(f, T, D)
%
% Input
%    f is the input image, a 2D array of real numbers
%    T is the tile size to break the input image into
%    D is the size of the block of Fourier coefficients to keep
%      (Bigger values of D result in less loss, but less compression)
%
% Output
%    G is the compressed encoding of the image
%
% Example: If f is 120x120, then
%
%    G = myJPEGCompress(f, 10, 4);
%
% would return an array (G) of size 48x48.
%
function G = myJPEGCompress(f, T, D)

	[h,w] = size(f);  % returns the width and height of f
    
    % === Replace the code below with your code ===
    
    m = floor(h/T);
    n = floor(w/T);
    G = zeros(m*D,n*D);
    for i = 1:m
        for j = 1:n
           tile = zeros(T);
           for a = 1:T
              for b = 1:T
                  tile(a,b)=f(a+(i-1)*T,b+(j-1)*T);
              end
           end
         tile = joDCT(tile);
         for a = 1:D
             for b = 1:D
                 G(a+(i-1)*D,b+(j-1)*D) = tile(a,b);
             end
         end
        end
    end
    
         
